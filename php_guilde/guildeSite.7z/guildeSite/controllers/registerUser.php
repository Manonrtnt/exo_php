<?php  
    //appel des fichiers dont j'aurais besoin
    include_once('../models/userbean.php'); // je peux également utiliser require ou include
    include_once('../utils/mydbconfig.php');
    include('../views/register.html');
    // contrôle de l'existence des champs fournis
    if(isset($_POST['pseudo'])
        && ($_POST['password'])
        && ($_POST['confPassword'])
        && ($_POST['mail'])
        && ($_POST['confMail'])){

        // je commence par créer des variables qui vont stocker les données envoyées par l'utilisateur 
        // en enlevant les blancs devant et derrière chaque données
        $pseudo = trim($_POST['pseudo']);
        $password = trim($_POST['password']);
        $confPassword = trim($_POST['confPassword']);
        $mail = trim($_POST['mail']);
        $confMail = trim($_POST['confMail']);

        // ensuite je vérifie que password et confPassword sont identiques
        if($password !== $confPassword) {
            echo '<p>Vots mots de passe ne sont pas identiques</p>';
        } else {
            // je vérifie si la valeur de $mail est bien un mail grâce à la fonction filter_var
            // qui prend la donnée en paramètre ainsi que FILTER_VALIDATE_EMAIL pour demander la vérification
            if(!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
                echo "<p>Cette adresse e-mail n'est pas valide</p>";
            } else if($mail !== $confMail) {
                echo "<p>Vos mails saisis ne sont pas identiques</p>";
            } else {
                // Pour la suite je n'aurais besoin que de 3 des 5 variables : $pseudo, $password et $mail.
                // Mais afin de sécuriser nos données nous allons effectuer des traitements à nos variables
                // en utilisant des fonctions PHP.
                // En effet nous allons vouloir nous protéger de toute injection de code HTML et/ou Javascript
                // par l'intermédiaire des variables qui contiennent les données envoyées par l'utilisateur.
                // Ces possibles failles sont appelées des failles XSS (Cross-Site Scripting).
                // Nous allons utiliser la fonction strip_tags qui permet de supprimer les balises HTML,
                // et la fonction htmlspecialchars qui permet de neutraliser les caractères &, ", ', <, >,
                // en les remplaçant par leurs codes &amp;, &quot;, &#039;, &lt; &gt;
                // ->  nb: il existe aussi la fonction htmlentities dont le rôle est de modifier toutes les balises HTML
        
                // je vais donc utiliser les 2 fonctions citées ci-dessus en les combinant
                // afin des traiter mes 3 variables $pseudo, $password et $mail.
                $verifPseudo = htmlspecialchars(strip_tags($pseudo));
                $verifPassword = htmlspecialchars(strip_tags($password));
                $verifMail = htmlspecialchars(strip_tags($mail));

                // je crée maintenant une nouvelle instance d'utilisateur
                $newUser = new UserBean();

                //j'utilise les setters de la classe pour affecter des valeurs aux attributs
                $newUser->setPseudo($verifPseudo);
                // pour l'affectation du mot de passe je vais également utiliser la fonction de hash de BCRYPT
                // pour crypter le mot de passe.
                $newUser->setPassword(password_hash($verifPassword, PASSWORD_BCRYPT));
                $newUser->setMail($verifMail);

                // une fois toutes les étapes précédentes réalisées, il ne reste plus qu'à appeler
                // la fonction createUser incluse dans la classe UserBean.
                $newUser->createUser();
            }
        }
    } else {
        echo '<P>Veuillez remplir tous les champs</P>';
    }

?>