<?php  
    class UserBean {
        // attributs pour se connecter à la BDD
        public $connect;
        private $table = 'userbean';

        //attributs de la classe selon ce que j'ai identifié
        // comme besoin et qui sont déjà implémenter dans la base de données

        private $idUser;
        private $pseudo;
        private $password;
        private $mail;
        private $idRoleGame;
        private $idRoleSite;

        // constructeur qui va établir la connexion à la BDD
        public function __construct() {
            $this->connect = new MyDBConfig();
            $this->connect = $this->connect->getConnection();
        }

        //génération des getters et setters
        public function getTable(){
            return $this->table;
        }
    
        public function getIdUser(){
            return $this->idUser;
        }
    
        public function getPseudo(){
            return $this->pseudo;
        }
        public function setPseudo($pseudo){
            $this->pseudo = $pseudo;
        }
    
        public function getPassword(){
            return $this->password;
        }
        public function setPassword($password){
            $this->password = $password;
        }
    
        public function getMail(){
            return $this->mail;
        }
        public function setMail($mail){
            $this->mail = $mail;
        }
    
        public function getIdRoleGame(){
            return $this->idRoleGame;
        }
        public function setIdRoleGame($idRoleGame){
            $this->idRoleGame = $idRoleGame;
        }
    
        public function getIdRoleSite(){
            return $this->idRoleSite;
        }
        public function setIdRoleSite($idRoleSite){
            $this->idRoleSite = $idRoleSite;
        }

        //création des méthodes de base  CRUD

        // Read pour récupérer la liste de tous les utilisateurs
        public function getUsers() {
            // stokage de la requête dans une variable
            $myQuery = 'SELECT * FROM '.$this->table.'';

            // stockage dans variable de la préparation de la requête
            $stmt = $this->connect->prepare($myQuery);

            //exécution de la requête
            $stmt->execute();

            // je retourne le résultat
            return $stmt;
        }

        //Read d'un seul utilisateur selon son pseudo
        //(peut-être modifié avec recherche par id ou mail, etc)

        public function getSingleUser() {
            // stokage de la requête dans une variable
            $myQuery = 'SELECT * FROM '.$this->table.' WHERE pseudo = '.$this->pseudo.'';

            // stockage dans variable de la préparation de la requête
            $stmt = $this->connect->prepare($myQuery);

            //exécution de la requête
            $stmt->execute();

            // je retourne le résultat
            return $stmt;
        }

        // Création et donc insertion d'un nouvel utilisateur dans la BDD
        // dans un premier temps nous ne tiendrons pas compte des champs
        // idRoleSite et idRoleGame
        public function createUser() {
            $myQuery = 'INSERT INTO
                            '.$this->table.'
                        SET
                            pseudo = :pseudo,
                            password = :password,
                            mail = :mail';
            // dans cette requête j'ai créé les paramètres :pseudo, :password et : mail 
            //auxquels j'attribuerais des valeurs lors du bind des paramètres

            $stmt = $this->connect->prepare($myQuery);

            // bind des paramètres
            $stmt->bindParam(':pseudo', $this->pseudo);
            $stmt->bindParam(':password', $this->password);
            $stmt->bindParam(':mail', $this->mail);

            return $stmt->execute();
        }

        // UPDATE mise à jour de l'utilisateur selon son pseudo
        public function updateUser(){
            $myQuery = 'UPDATE
                            '.$this->table.'
                        SET
                            pseudo = :pseudo,
                            password = :password,
                            mail = :mail
                        WHERE
                            pseudo = :pseudo2';

            $stmt = $this->connect->prepare($myQuery);

            // bind des paramètres
            $stmt->bindParam(':pseudo', $this->pseudo);
            $stmt->bindParam(':password', $this->password);
            $stmt->bindParam(':mail', $this->mail);
            $stmt->bindParam(':pseudo2', $this->pseudo);

            if($stmt->execute) {
                // je retourne true si mise à jour réussie
                return true;
            } else {
                return false;
            }
            // ci-dessus je peux simplifier en écrivant return $stmt->execute();
        }

        // DELETE suppression d'un utilisateur selon pseudo 
        // (on peut aussi avec un autre attribut selon son besoin)
        public function deleteUser() {
            $myQuery = 'DELETE FROM '.$this->table.' WHERE pseudo = '.$this->pseudo.'';

            $stmt = $this->connect->prepare($myQuery);

            $stmt->bindParam(':pseudo', $this->pseudo);

            if($stmt->execute) {
                // je retourne true si mise à jour réussie
                return true;
            } else {
                return false;
            }
        }
    }
?>