<?php  
    class RoleGameBean {
        // attributs pour se connecter à la BDD
        public $connect;
        private $table = 'rolegamebean';

        //attributs de la classe selon ce que j'ai identifié
        // comme besoin et qui sont déjà implémenter dans la base de données
        private $idRoleGame;
        private $roleGameName;

        // constructeur qui va établir la connexion à la BDD
        public function __construct() {
            $this->connect = new MyDBConfig();
            $this->connect = $this->connect->getConnection();
        }

        //génération des getters et setters
        public function getTable(){
            return $this->table;
        }
    
        public function getIdRoleGame(){
            return $this->idRoleGame;
        }

        public function getRoleGameName(){
            return $this->roleGameName;
        }
        public function setRoleGameName($roleGameName){
            $this->roleGameName = $roleGameName;
        }

        //création des méthodes de base  CRUD

        public function getRolesGame() {
            // stokage de la requête dans une variable
            $myQuery = 'SELECT * FROM '.$this->table.'';

            // stockage dans variable de la préparation de la requête
            $stmt = $this->connect->prepare($myQuery);

            //exécution de la requête
            $stmt->execute();

            // je retourne le résultat
            return $stmt;
        }

        public function getSingleRoleGame() {
            // stokage de la requête dans une variable
            $myQuery = 'SELECT * FROM '.$this->table.' WHERE roleGameName = '.$this->roleGameName.'';

            // stockage dans variable de la préparation de la requête
            $stmt = $this->connect->prepare($myQuery);

            //exécution de la requête
            $stmt->execute();

            // je retourne le résultat
            return $stmt;
        }

        public function createRoleSite() {
            $myQuery = 'INSERT INTO
                            '.$this->table.'
                        SET
                            roleGameName = :roleGameName';

            $stmt = $this->connect->prepare($myQuery);

            // bind des paramètres
            $stmt->bindParam(':roleGameName', $this->roleGameName);

            return $stmt->execute();
        }

        // UPDATE mise à jour de l'utilisateur selon son pseudo
        public function updateRoleSite(){
            $myQuery = 'UPDATE
                            '.$this->table.'
                        SET
                            roleGameName = :roleGameName
                        WHERE
                            roleGameName = :roleGameName2';

            $stmt = $this->connect->prepare($myQuery);

            // bind des paramètres
            $stmt->bindParam(':roleGameName', $this->roleGameName);
            $stmt->bindParam(':roleGameName2', $this->roleGameName);

            if($stmt->execute) {
                // je retourne true si mise à jour réussie
                return true;
            } else {
                return false;
            }
            // ci-dessus je peux simplifier en écrivant return $stmt->execute();
        }

        public function deleteRoleSite() {
            $myQuery = 'DELETE FROM '.$this->table.' WHERE roleGameName = :roleGameName';

            $stmt = $this->connect->prepare($myQuery);

            $stmt->bindParam(':roleGameName', $this->roleGameName);

            if($stmt->execute) {
                // je retourne true si mise à jour réussie
                return true;
            } else {
                return false;
            }
        }
    }
?>