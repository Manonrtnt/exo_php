<?php  
    class RoleSiteBean {
        // attributs pour se connecter à la BDD
        public $connect;
        private $table = 'rolesitebean';

        //attributs de la classe selon ce que j'ai identifié
        // comme besoin et qui sont déjà implémenter dans la base de données
        private $idRoleSite;
        private $roleSiteName;

        // constructeur qui va établir la connexion à la BDD
        public function __construct() {
            $this->connect = new MyDBConfig();
            $this->connect = $this->connect->getConnection();
        }

        //génération des getters et setters
        public function getTable(){
            return $this->table;
        }
    
        public function getIdRoleSite(){
            return $this->idRoleSite;
        }

        public function getRoleSiteName(){
            return $this->roleSiteName;
        }
        public function setRoleSiteName($roleSiteName){
            $this->roleSiteName = $roleSiteName;
        }

        //création des méthodes de base  CRUD

        public function getRolesSite() {
            // stokage de la requête dans une variable
            $myQuery = 'SELECT * FROM '.$this->table.'';

            // stockage dans variable de la préparation de la requête
            $stmt = $this->connect->prepare($myQuery);

            //exécution de la requête
            $stmt->execute();

            // je retourne le résultat
            return $stmt;
        }

        public function getSingleRoleSite() {
            // stokage de la requête dans une variable
            $myQuery = 'SELECT * FROM '.$this->table.' WHERE roleSiteName = '.$this->roleSiteName.'';

            // stockage dans variable de la préparation de la requête
            $stmt = $this->connect->prepare($myQuery);

            //exécution de la requête
            $stmt->execute();

            // je retourne le résultat
            return $stmt;
        }

        public function createRoleSite() {
            $myQuery = 'INSERT INTO
                            '.$this->table.'
                        SET
                            roleSiteName = :roleSiteName';

            $stmt = $this->connect->prepare($myQuery);

            // bind des paramètres
            $stmt->bindParam(':roleSiteName', $this->roleSiteName);

            return $stmt->execute();
        }

        // UPDATE mise à jour de l'utilisateur selon son pseudo
        public function updateRoleSite(){
            $myQuery = 'UPDATE
                            '.$this->table.'
                        SET
                            roleSiteName = :roleSiteName
                        WHERE
                            roleSiteName = :roleSiteName2';

            $stmt = $this->connect->prepare($myQuery);

            // bind des paramètres
            $stmt->bindParam(':roleSiteName', $this->roleSiteName);
            $stmt->bindParam(':roleSiteName2', $this->roleSiteName);

            if($stmt->execute) {
                // je retourne true si mise à jour réussie
                return true;
            } else {
                return false;
            }
            // ci-dessus je peux simplifier en écrivant return $stmt->execute();
        }

        // DELETE suppression d'un utilisateur selon pseudo 
        // (on peut aussi avec un autre attribut selon son besoin)
        public function deleteRoleSite() {
            $myQuery = 'DELETE FROM '.$this->table.' WHERE roleSiteName = :roleSiteName';

            $stmt = $this->connect->prepare($myQuery);

            $stmt->bindParam(':roleSiteName', $this->roleSiteName);

            if($stmt->execute) {
                // je retourne true si mise à jour réussie
                return true;
            } else {
                return false;
            }
        }
    }
?>